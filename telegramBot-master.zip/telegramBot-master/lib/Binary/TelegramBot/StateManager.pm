package Binary::TelegramBot::StateManager;

use Exporter qw(import);
use Data::Dumper;

our @EXPORT = qw();

my $hash = {};

